<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo app('translator')->get('languages.titles.login_page'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
    <script src="<?php echo e(asset('js/javascript.js')); ?>"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;800&display=swap" rel="stylesheet">
</head>

<body>
    <div class="background">
        <div class="overlay"></div>
        <div class="content">
            <div class="navigation-container">
                <div class="cancel-button-container">
                    <button class="cancel-button" onclick="location.href='/'">&larr; <?php echo app('translator')->get('languages.buttons.cancel'); ?></button>
                </div>
                <div class="tabs-container">
                    <div class="form-switcher">
                        <span class="switcher login active"><?php echo app('translator')->get('languages.buttons.login'); ?></span>
                        <span class="switcher register" onclick="location.href='register'"><?php echo app('translator')->get('languages.buttons.register'); ?></span>
                    </div>
                </div>
            </div>
            <form action="login" method="POST" class="form-box">
                <?php if(Session::has('success')): ?>
                    <<div class="content-box">
                        <div class="pops">
                            <p><span style="color:green"><?php echo e(Session::get('success')); ?></span></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="content-box">
                        <div class="pops">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><span class="failed"><?php echo e($item); ?></span></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email"><?php echo app('translator')->get('languages.labels.email'); ?></label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                        oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.login.warning_email'); ?>')" oninput="this.setCustomValidity('')"
                        required>
                </div>
                <div class="form-group">
                    <label for="password"><?php echo app('translator')->get('languages.labels.password'); ?></label>
                    <input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>"
                        oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.login.warning_password'); ?>')" oninput="this.setCustomValidity('')"
                        required>
                </div>
                <div class="buttons">
                    <button type="submit" class="blue-button"><?php echo app('translator')->get('languages.buttons.login'); ?></button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\permision-chat\resources\views/login.blade.php ENDPATH**/ ?>