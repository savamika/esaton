<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo app('translator')->get('languages.titles.register_page'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;800&display=swap" rel="stylesheet">
</head>

<body>
    <div class="background">
        <div class="overlay"></div>


        <div class="content">
            <div class="navigation-container">
                <div class="cancel-button-container">
                    <button class="cancel-button" onclick="location.href='/'">&larr; <?php echo app('translator')->get('languages.buttons.cancel'); ?></button>
                </div>
                <div class="tabs-container">
                    <div class="form-switcher">
                        <span class="switcher login" onclick="location.href='login'"><?php echo app('translator')->get('languages.buttons.login'); ?></span>
                        <span class="switcher register active"><?php echo app('translator')->get('languages.buttons.register'); ?></span>
                    </div>
                </div>
            </div>
            <form action="register" method="POST" class="form-box" enctype="multipart/form-data">
                <?php if(Session::has('success')): ?>
                    <div class="content-box">
                        <div class="pops">
                            <p><span style="color:green"><?php echo e(Session::get('success')); ?></span></p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="content-box">
                        <div class="pops">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><span class="failed"><?php echo e($item); ?></span></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <!-- Row for First Name & Last Name -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="firstname"><?php echo app('translator')->get('languages.labels.frm_firstname'); ?></label>
                        <input type="text" id="firstname" name="firstname" value="<?php echo e(old('firstname')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_firstname'); ?>')" oninput="this.setCustomValidity('')"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="lastname"><?php echo app('translator')->get('languages.labels.frm_lastname'); ?></label>
                        <input type="text" id="lastname" name="lastname" value="<?php echo e(old('lastname')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_lastname'); ?>')" oninput="this.setCustomValidity('')"
                            required>
                    </div>
                </div>

                <!-- Row for Email -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="email"><?php echo app('translator')->get('languages.labels.frm_email'); ?></label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_email'); ?>')" oninput="this.setCustomValidity('')"
                            required>
                    </div>

                    <div class="form-group">
                        <label for="conf_email"><?php echo app('translator')->get('languages.labels.frm_confrm_email'); ?></label>
                        <input type="email" id="conf_email" name="conf_email" value="<?php echo e(old('conf_email')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_conf_email'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>

                </div>
                <div class="form-row">
                    <!-- Password field -->
                    <div class="form-group password-group">
                        <label for="password"><?php echo app('translator')->get('languages.labels.frm_password'); ?></label>
                        <input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_password'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                    <!-- Password Repeat field -->
                    <div class="form-group password-group">
                        <label for="password-repeat"><?php echo app('translator')->get('languages.labels.frm_confrm_password'); ?></label>
                        <input type="password" id="password-repeat" name="password_repeat"
                            value="<?php echo e(old('password_repeat')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_password_repeat'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                </div>

                <!-- Row for Country & City -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="age"><?php echo app('translator')->get('languages.labels.frm_age'); ?></label>
                        <input type="number" min="1" id="age" name="age" value="<?php echo e(old('age')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_age'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="country"><?php echo app('translator')->get('languages.labels.frm_country'); ?></label>
                        <input type="text" id="country" name="country" value="<?php echo e(old('country')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_country'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city"><?php echo app('translator')->get('languages.labels.frm_city'); ?></label>
                        <input type="text" id="city" name="city" value="<?php echo e(old('city')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_city'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                </div>

                <!-- Row for Job & Education -->
                <div class="form-row">
                    <div class="form-group">
                        <label for="job"><?php echo app('translator')->get('languages.labels.frm_job'); ?></label>
                        <input type="text" id="job" name="job" value="<?php echo e(old('job')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_job'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                    <div class="form-group">
                        <label for="company"><?php echo app('translator')->get('languages.labels.frm_company'); ?></label>
                        <input type="text" id="company" name="company" value="<?php echo e(old('company')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_company'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                    <div class="form-group">
                        <label for="education"><?php echo app('translator')->get('languages.labels.frm_education'); ?></label>
                        <input type="text" id="education" name="education" value="<?php echo e(old('education')); ?>"
                            oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_education'); ?>')"
                            oninput="this.setCustomValidity('')" required>
                    </div>
                </div>

                <div class="form-group ref-group">
                    <label for="Referral"><?php echo app('translator')->get('languages.labels.frm_referral_code'); ?></label>
                    <input type="Referral" id="Referral" name="referral_code">
                </div>

                <!-- Full-width field for Photo -->
                <div class="form-group">
                    <input type="file" id="photo" name="photo" value="<?php echo e(old('photo')); ?>" accept="image/png, image/jpeg"
                        oninvalid="this.setCustomValidity('<?php echo app('translator')->get('languages.notif.register.warning_photo'); ?>')" oninput="this.setCustomValidity('')">
                    <label for="photo" class="custom-file-upload">
                        <i class="fa fa-cloud-upload"></i> <?php echo app('translator')->get('languages.labels.frm_choose_photo'); ?>
                    </label>
                </div>

                <div class="buttons">
                    <button type="submit" class="blue-button"><?php echo app('translator')->get('languages.buttons.register'); ?></button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\permision\resources\views/register.blade.php ENDPATH**/ ?>